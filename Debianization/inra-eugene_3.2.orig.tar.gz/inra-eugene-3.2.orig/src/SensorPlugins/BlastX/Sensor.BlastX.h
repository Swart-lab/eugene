// ------------------------------------------------------------------
// Copyright (C) 2004 INRA <eugene@ossau.toulouse.inra.fr>
//
// This program is open source; you can redistribute it and/or modify
// it under the terms of the Artistic License (see LICENSE file).
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
//
// You should have received a copy of Artistic License along with
// this program; if not, please see http://www.opensource.org
//
// $Id: Sensor.BlastX.h,v 1.22 2004/12/02 16:37:32 bardou Exp $
// ------------------------------------------------------------------
// File:     Sensor.BlastX.h
// Contents: Sensor BlastX
// ------------------------------------------------------------------


#ifndef  SENSOR_BLASTX_H_INCLUDED
#define  SENSOR_BLASTX_H_INCLUDED

#include "../../Sensor.h"
#include "../../Hits.h"

/*************************************************************
 **                     SensorBlastX                        **
 *************************************************************/
class SensorBlastX : public Sensor
{
 private:
  double *ProtMatch, *ProtMatchLevel;
  int    *ProtMatchPhase;
  std::vector<int>    vPos,     vPMPhase;
  std::vector<double> vPMLevel, vPMatch;
  std::vector<int>::iterator iter;
  char *levels;
  int    index;
  double keyBXLevel[10];
  int    minIn;
  int    blastxM;
  int    ppNumber;
  int    stepid;
  int    N;
  int    sloppy;

  void LoadContentScore (DNASeq *);
  char ph06             (char);

  // For postprocess 2
  Hits **HitTable;
  int  NumProt;
  void ProtSupport (Prediction *pred, int debut, int fin,
		    Hits **HitTable,  int Size,  int NumG);
  int  LenSup      (Hits **HitTable, Prediction *pred,
		    std::vector<int> vSupProtI,
		    int index, int beg, int end);
  
 public:
  SensorBlastX  (int n, DNASeq *X);
  virtual ~SensorBlastX   ();
  virtual void Init       (DNASeq *);
  virtual void GiveInfo   (DNASeq *, int, DATA *);
  virtual void Plot       (DNASeq *);
  virtual void PostAnalyse(Prediction *);
};

extern "C" SensorBlastX * builder0( int n, DNASeq *X) { return new SensorBlastX(n, X); }
#endif
